-- Add new category values to resource_category enum
ALTER TYPE resource_category ADD VALUE 'All Units Resources';
ALTER TYPE resource_category ADD VALUE 'Additional Resources';